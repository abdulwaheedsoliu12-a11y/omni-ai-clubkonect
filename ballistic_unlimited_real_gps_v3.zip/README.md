# Ballistic Unlimited — Real GPS Live Location v3

## Included
- Permission-based browser GPS (`watchPosition`)
- Live latitude/longitude/accuracy/speed/heading
- Animated 3D-style globe + radar visualization
- WebSocket multi-device sharing by explicit room
- SQLite location history
- REST history API
- Session/room creation with expiration
- Local offline track buffering in browser
- CSV export
- Geofences with enter/exit events
- Local device ID
- Responsive cyberpunk dashboard
- No IP-to-GPS, phone-number tracking, hidden tracking, or covert collection

## Run on a computer
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8000
```

Open `http://127.0.0.1:8000/`.

## Important for real phone GPS
Browsers normally require a secure context for geolocation. `localhost` is treated specially, but when opening the dashboard from another phone over a LAN IP, use HTTPS or a trusted local development setup.

For WebSocket sharing, put:
`ws://YOUR_SERVER:8000/ws/ROOMCODE`
into the server field.

Create a room with:
`POST /api/rooms` with `{"ttl_seconds":3600}`.

## Privacy
Every device must explicitly press START GPS / SHARE and grant browser location permission. Stop sharing at any time. The server stores only coordinates sent to it by an opted-in client. For production deployment, add real authentication, HTTPS/WSS, access controls, rate limits, retention policies, and encrypted database storage.
