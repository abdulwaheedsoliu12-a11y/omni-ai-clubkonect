from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import sqlite3, json, math, time, secrets
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DB=ROOT/"gps.db"
app=FastAPI(title="Ballistic Unlimited GPS API", version="3.0")

def db():
    c=sqlite3.connect(DB)
    c.execute("""CREATE TABLE IF NOT EXISTS locations(
        id INTEGER PRIMARY KEY AUTOINCREMENT, room TEXT, device_id TEXT,
        lat REAL, lon REAL, accuracy REAL, speed REAL, heading REAL, ts REAL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS rooms(
        room TEXT PRIMARY KEY, created REAL, expires REAL)""")
    c.commit(); return c

def distance(a,b,c,d):
    R=6371000; p=math.pi/180
    x=(c-a)*p; y=(d-b)*p
    q=math.sin(x/2)**2+math.cos(a*p)*math.cos(c*p)*math.sin(y/2)**2
    return 2*R*math.asin(math.sqrt(q))

class RoomCreate(BaseModel):
    ttl_seconds:int=3600

connections={}
@app.get("/api/health")
def health(): return {"ok":True,"service":"gps","time":time.time()}

@app.post("/api/rooms")
def create_room(body:RoomCreate):
    ttl=max(60,min(body.ttl_seconds,86400))
    room=secrets.token_urlsafe(6).upper()
    c=db(); c.execute("INSERT INTO rooms VALUES(?,?,?)",(room,time.time(),time.time()+ttl)); c.commit(); c.close()
    return {"room":room,"expires_in":ttl}

@app.get("/api/rooms/{room}/history")
def history(room:str,limit:int=500):
    c=db(); rows=c.execute("""SELECT device_id,lat,lon,accuracy,speed,heading,ts
      FROM locations WHERE room=? ORDER BY ts DESC LIMIT ?""",(room.upper(),min(limit,5000))).fetchall(); c.close()
    return {"room":room.upper(),"locations":[dict(zip(["device_id","lat","lon","accuracy","speed","heading","timestamp"],r)) for r in rows]}

@app.websocket("/ws/{room}")
async def ws_endpoint(ws:WebSocket,room:str):
    await ws.accept(); room=room.upper()
    connections.setdefault(room,set()).add(ws)
    try:
        while True:
            msg=await ws.receive_text()
            data=json.loads(msg)
            if data.get("type")!="location": continue
            # Only accept client-supplied, consented GPS updates; no IP/phone lookup.
            lat=float(data["lat"]); lon=float(data["lon"])
            if not (-90<=lat<=90 and -180<=lon<=180): continue
            payload={"type":"location","room":room,"device_id":str(data["device_id"]),
                     "lat":lat,"lon":lon,"accuracy":float(data.get("accuracy",0)),
                     "speed":data.get("speed"),"heading":data.get("heading"),"timestamp":float(data.get("timestamp",time.time()*1000))}
            c=db(); c.execute("INSERT INTO locations(room,device_id,lat,lon,accuracy,speed,heading,ts) VALUES(?,?,?,?,?,?,?,?)",
                (room,payload["device_id"],lat,lon,payload["accuracy"],payload["speed"],payload["heading"],payload["timestamp"])); c.commit(); c.close()
            dead=[]
            for peer in connections.get(room,set()):
                if peer is ws: continue
                try: await peer.send_text(json.dumps(payload))
                except: dead.append(peer)
            for peer in dead: connections[room].discard(peer)
    except WebSocketDisconnect:
        connections.get(room,set()).discard(ws)

app.mount("/static",StaticFiles(directory=ROOT/"static"),name="static")
@app.get("/")
def index(): return FileResponse(ROOT/"static/index.html")
